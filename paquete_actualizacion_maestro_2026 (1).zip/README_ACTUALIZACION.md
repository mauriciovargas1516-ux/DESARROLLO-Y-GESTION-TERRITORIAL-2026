# Paquete de Actualización Maestro - ULagos 2026
Incluye:
- `central_mando_github.py`: CMS remoto con soporte de despliegue por lotes y .ZIP automático.
- `puente_drive_sincronizador.py`: Nuevo módulo `.py` para sincronización con Google Drive API y GitHub API.
