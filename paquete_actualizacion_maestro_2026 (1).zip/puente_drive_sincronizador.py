# -*- coding: utf-8 -*-
"""
Módulo nuevo: puente_drive_sincronizador.py
Conecta cualquier aplicación Streamlit del ecosistema ULagos 2026 con Google Drive API (5 TB)
y GitHub API para extracción de metadatos y búsqueda de literatura en tiempo real.
"""

import os
import io
import json
import urllib.request
import streamlit as st
from google.oauth2 import service_account
from googleapiclient.discovery import build

def inicializar_conexion_drive():
    try:
        if "gcp_service_account_json" in st.secrets:
            secret_dict = dict(st.secrets["gcp_service_account_json"])
            creds = service_account.Credentials.from_service_account_info(
                secret_dict, scopes=["https://www.googleapis.com/auth/drive.readonly"]
            )
            service = build("drive", "v3", credentials=creds)
            return service
    except Exception as e:
        st.warning(f"Aviso conexión Drive API: {e}")
    return None

def buscar_documento_drive(service, q_nombre):
    if not service:
        return []
    try:
        results = service.files().list(
            q=f"name contains '{q_nombre}' and trashed = false",
            pageSize=10,
            fields="files(id, name, mimeType, webViewLink)"
        ).execute()
        return results.get("files", [])
    except Exception:
        return []

def renderizar_puente_literatura(nombre_repo_actual=""):
    st.markdown("---")
    st.markdown(f"### PUENTE CENTRAL DE LITERATURA Y VISOR GOOGLE DRIVE API (5 TB) - {nombre_repo_actual.upper()}")
    st.caption("Conectado en tiempo real a Google Cloud y GitHub API para extracción de portafolio y literatura de cátedra.")
    
    col1, col2 = st.columns([2, 1])
    with col1:
        query_busqueda = st.text_input("Buscar documento normativo o literatura en Google Drive:", value="Precios Sociales 2026")
    with col2:
        btn_buscar = st.button("Buscar en Drive 5 TB", use_container_width=True)
        
    if btn_buscar:
        srv = inicializar_conexion_drive()
        if srv:
            docs = buscar_documento_drive(srv, query_busqueda)
            if docs:
                for d in docs:
                    st.markdown(f"- **[{d['name']}]({d.get('webViewLink', '#')})** (ID: `{d['id']}`)")
            else:
                st.info("No se encontraron documentos exactos con ese nombre en Drive.")
        else:
            st.error("No se pudo autenticar con la cuenta de servicio de Google Drive (verifica st.secrets).")
